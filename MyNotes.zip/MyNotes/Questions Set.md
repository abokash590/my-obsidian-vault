# Saic Institute of Management & Technology
# CSE-3202: Numerical Methods

## Class Tests — CT 1 & CT 2

---

# 📄 CT 1

## Question 1 — Gauss Elimination

Solve the following system using **Gauss Elimination method**:

```
2x + y − 3z =  11
4x − 2y + 3z =  8
-2x + 2y −  z = −6
```


---

## Question 2 — Gauss-Jordan Method

Solve the following system of equations using the **Gauss-Jordan method**:

```
6x + 15y +  2z =  72
 x +   y + 54z = 110
27x +  6y − z =  85
```

---

## Question 3

Find the real root of the equation `cos x = 3x − 1`, correct to five decimal places, using the **Fixed Point Iteration method**.

---

## Question 4

Find y(0.2) for `y' = x − y²`, y(0) = 1, with step length h = 0.1, using the **Modified Euler's method**.

---

---

# 📄 CT 2

## Question 1 — Gauss-Seidel Method

Solve the following system of equations correct to 4 decimal places using the **Gauss-Seidel Method**:

```
2x +  y −  2z = 17
3x + 20y −  z = −18
2x −  3y + 20z = 25
```

---

## Question 2 — Cramer's Rule

Solve the following system of equations using **Cramer's Rule**:

```
2x +  y − z = 3
 x −  y + 2z = 2
3x + 2y −  z = 5
```

---

## Question 3 — Taylor's Series

Find y(0.2), correct to four decimal places, using the **Taylor's series method**, up to 3 terms, given: 

$$\frac{dy}{dx} = x^2 + y, \quad y(0) = 1$$

---

*End of CT-1 & CT-2 Question Sets*